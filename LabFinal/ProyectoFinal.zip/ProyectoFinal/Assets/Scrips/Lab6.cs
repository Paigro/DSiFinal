using System.Collections;

using Unity.VisualScripting;

using UnityEngine;
using UnityEngine.UIElements;

using System;
using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using System.Xml.Linq;
using static UnityEngine.GraphicsBuffer;

namespace Lab6_namespace
{
    public class Lab6 : MonoBehaviour
    {
        VisualElement botonCrear; // Boton para crear nueva etiqueta.
        Toggle toggleModificar; // Boton de true/false para modificar.
        VisualElement contenedor_dcha; // Lugar de la derecha donde aparecen las tarjetas.
        TextField input_nombre; // Donde se pone el nombre.
        TextField input_apellido; // Donde se pone el apellido.
        Individuo individuoSelec; // La tarjeta seleccionada.

        VisualElement gato; // Imagen del gato.
        VisualElement girafa; // Imagen de la girafa.
        VisualElement conejo; // imagen del conejo.
        private string backgroundSprite = "panda"; // String para cambiar la foto de la nueva tarjeta.

        private int maxIndvs = 4; // Maximo de tarjetas.
        private int indvs = 0; // Tarjetas actuales.


        List<Individuo> list_individuos = new List<Individuo>(); // Lista de tarjetas que creas.
        private void OnEnable()
        {
            VisualElement root = GetComponent<UIDocument>().rootVisualElement; // Todo el documento para coger las cosas.

            // Asigancion de cosas:
            contenedor_dcha = root.Q<VisualElement>("Dcha");
            input_nombre = root.Q<TextField>("InputN");
            input_apellido = root.Q<TextField>("InputA");
            botonCrear = root.Q<VisualElement>("BotonCrear");
            toggleModificar = root.Q<Toggle>("ToggleModificar");

            gato = root.Q<VisualElement>("gato");
            girafa = root.Q<VisualElement>("girafa");
            conejo = root.Q<VisualElement>("conejo");

            // Callbacks:
            contenedor_dcha.RegisterCallback<ClickEvent>(SeleccionarTarjeta);
            botonCrear.RegisterCallback<ClickEvent>(NuevaTarjeta);
            input_nombre.RegisterCallback<ChangeEvent<string>>(CambioNombre);
            input_apellido.RegisterCallback<ChangeEvent<string>>(CambioApellido);
            gato.RegisterCallback<ClickEvent>(SeleccionGato);
            girafa.RegisterCallback<ClickEvent>(SeleccionGirafa);
            conejo.RegisterCallback<ClickEvent>(SeleccionConejo);
        }
        void NuevaTarjeta(ClickEvent evt) // Se llama para crear una tarjeta.
        {
            if (!toggleModificar.value && indvs < maxIndvs) // Solo si el boton de modificar esta deseleccionado y hay menos de 4 tarjetas.
            {
                VisualTreeAsset plantilla = Resources.Load<VisualTreeAsset>("plantilla"); // Coje la plantilla que se quiere crear. En PF np esta no va a funcionar.
                VisualElement tarjetaPlatilla = plantilla.Instantiate(); // La instancia.

                contenedor_dcha.Add(tarjetaPlatilla); // La pone a la derecha.
                tarjetas_borde_negro(); // Llama para que se pongan todos los bordes en negro.
                tarjetas_borde_blanco(tarjetaPlatilla); // Llama para que este borde se ponga en blanco.

                Individuo indv = new Individuo(input_nombre.value, input_apellido.value); // Le pone el nombre y apellido que halla en las cajas de input.
                Tarjeta tarj = new Tarjeta(tarjetaPlatilla, indv); // Crea la tarjeta.
                individuoSelec = indv; // Lo pone como seleccionado.

                list_individuos.Add(indv); // Lo mete a la lista.
                
                
                // Las cosas del json no funcionan:
                /* list_individuos.ForEach(elem =>
                 {
                     Debug.Log(elem.Nombre + " " + elem.Apellido);
                     string jsonIndividuo = JsonUtility.ToJson(elem);
                     Debug.Log(jsonIndividuo);
                 });*/
                /*string listToJson = JSonHelperIndividuo.ToJson(list_individuos, true); // PAIGRO AQUI
                Debug.Log(listToJson);*/

                /* List<Individuo> jsonToLista = JSonHelperIndividuo.FromJson<Individuo>(listToJson);
                 jsonToLista.ForEach(elem =>
                 {
                     Debug.Log(elem.Nombre + " " + elem.Apellido);
                 });*/


                indvs++; // Suamamos un individuos.
            }
        }

        void CambioNombre(ChangeEvent<string> evt) // Cuando se escribe en la caja se modifica el nombre.
        {
            if (toggleModificar.value)
            {
                individuoSelec.Nombre = evt.newValue;
            }
        }
        void CambioApellido(ChangeEvent<string> evt) // Cuando se escribe en la caja se modifica el apellido.
        {
            if (toggleModificar.value)
            {
                individuoSelec.Apellido = evt.newValue;
            }
        }
        void SeleccionarTarjeta(ClickEvent evt)
        {
            VisualElement miTarjeta = evt.target as VisualElement; // Cogemos la tarjeta seleccionada.
            individuoSelec = miTarjeta.userData as Individuo; // Cogemos el individuo seleccionado.

            input_nombre.SetValueWithoutNotify(individuoSelec.Nombre); // Esto supongo que cambia el nombre y eso.
            input_apellido.SetValueWithoutNotify(individuoSelec.Apellido); // Y esto el apellido.
            toggleModificar.value = true; // Pone el boton a true para saber que se esta modificando.

            tarjetas_borde_negro(); // Lo mismo que antes.
            tarjetas_borde_blanco(miTarjeta);
        }
        void tarjetas_borde_negro()
        {
            // Coge toda la lista y pone sus bordes a negro para deseleccionarlos.
            List<VisualElement> lista_tarjetas = contenedor_dcha.Children().ToList();
            lista_tarjetas.ForEach(elem =>
            {
                VisualElement tarjeta = elem.Q("plantilla"); 

                tarjeta.style.borderBottomColor = Color.black;
                tarjeta.style.borderRightColor = Color.black;
                tarjeta.style.borderTopColor = Color.black;
                tarjeta.style.borderLeftColor = Color.black;

            });
        }
        void tarjetas_borde_blanco(VisualElement tar)
        {
            // Cambia el borde de la tarjeta seleccionada a blanco para marcarla.
            VisualElement tarjeta = tar.Q("plantilla");

            tarjeta.style.borderBottomColor = Color.white;
            tarjeta.style.borderRightColor = Color.white;
            tarjeta.style.borderTopColor = Color.white;
            tarjeta.style.borderLeftColor = Color.white;

            // Esto cambia la imagen por la que se haya seleccionado al pulsar las imagenes de gato, girafa y conejo.
            VisualElement top = tar.Q("top");
            top.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>(backgroundSprite));
        }
        // Esto para cambiar el string y se guarde que quieres cambiar de imagen de tarjeta.
        void SeleccionGato(ClickEvent evt)
        {
            backgroundSprite = "gato";
            Debug.Log("Sprite gato");
        }
        void SeleccionGirafa(ClickEvent evt)
        {
            backgroundSprite = "girafa";
            Debug.Log("Sprite girafa");
        }
        void SeleccionConejo(ClickEvent evt)
        {
            backgroundSprite = "conejo";
            Debug.Log("Sprite conejo");
        }
    }
}