using UnityEngine;
using UnityEngine.UIElements;

public class Lab4d : MonoBehaviour
{
    private P4 estrellitas;

    private void OnEnable()
    {
        VisualElement rootve = GetComponent<UIDocument>().rootVisualElement;

        estrellitas = (P4)rootve.Q("P4");

        VisualElement espageti = rootve.Q("Espagueti");
        VisualElement fetuccine = rootve.Q("Fettuccine");
        VisualElement ribatoni = rootve.Q("Rigatoni");

        espageti.AddManipulator(new P4Manipulator());
        fetuccine.AddManipulator(new P4Manipulator());
        ribatoni.AddManipulator(new P4Manipulator());
    
        espageti.AddManipulator(new P4PointerManipulator(estrellitas,1));
        fetuccine.AddManipulator(new P4PointerManipulator(estrellitas,6));
        ribatoni.AddManipulator(new P4PointerManipulator(estrellitas,3));
    }

}
