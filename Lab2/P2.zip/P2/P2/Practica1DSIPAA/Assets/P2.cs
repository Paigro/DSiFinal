using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UIElements;

public class P2 : MonoBehaviour
{
    //// Start is called before the first frame update
    //void Start()
    //{

    //}

    //// Update is called once per frame
    //void Update()
    //{

    //}

    private void OnEnable()
    {
        //PRACTICA DE ACCESO A ELEMENTOS DE UN MENU MEDIANTE UQUERY

        UIDocument menusa = GetComponent<UIDocument>();                                         //Acceso a componente UIDocument
        VisualElement rootve = menusa.rootVisualElement;                                        //Declaracion rootve

        //UQueryBuilder<VisualElement> builder = new(rootve);                                   //Comun a AddToClassList y Children
        //List<VisualElement> lista_ve = builder.ToList();                                      //AddToClassList
        //List<VisualElement> lista_ve = builder.ToList();                                      //ClassName
        //List<VisualElement> lista_ve = rootve.Query(className: "PagesStyleSheet").ToList(); //Query     +      ClassName

        //VisualElement ve = rootve.Query(className: "PagesStyleSheet").First();                //Acceso al primer componente de la lista con Query.First o Q
        //Debug.Log(ve.name);
        //ve.AddToClassList("TitlesStyleSheet");

        //VisualElement ve = rootve.Query<Label>().Last();                                       //Acceso al �ltimo componente de una clase con Query<type>
        //Debug.Log(ve.name);
        //ve.AddToClassList("PagesStyleSheet");

        VisualElement ve = rootve.Query<Label>().AtIndex(3);                                 //Acceso al componente de una clase determinado con un �ndice por Query<type>.AtIndex()
        Debug.Log(ve.name);
        ve.AddToClassList("PagesStyleSheet");


        //VisualElement contenedor = builder.Name("Menu");                                      //Children
        //List<VisualElement> lista_ve = contenedor.Children().ToList();                        //Children

        //lista_ve.ForEach(elem => {Debug.Log(elem.name);                                       //Linea comun a todas las pruebas
        //    elem.AddToClassList("PostresStyleSheet");});                                      //Linea comun a todas las pruebas
    }
}
