using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.UIElements;

public class PFpestana : MonoBehaviour
{
    VisualElement botNieves,
        botPaigro,
        botAndres,
        torNieves,
        torPaigro,
        torAndres;


    int espaciosOcupados = 0;
    //Stats
    int magico = 0,
        psiquico = 0,
        fisico = 0;
    VisualElement[] huecos = new VisualElement[4];

    VisualElement magiaEst;
    VisualElement psiquicoEst;
    VisualElement fisicoEst;

    private void NoContenido()
    {
        torNieves.style.display = DisplayStyle.None;
        torPaigro.style.display = DisplayStyle.None;
        torAndres.style.display = DisplayStyle.None;
    }

    private void OnEnable()
    {
        VisualElement rootve = GetComponent<UIDocument>().rootVisualElement;

        botPaigro = rootve.Q("PaigroBot");
        botAndres = rootve.Q("AndresBot");
        botNieves = rootve.Q("NievesBot");

        torPaigro = rootve.Q("Paigro");
        torNieves = rootve.Q("Nieves");
        torAndres = rootve.Q("Andres");

        botPaigro.RegisterCallback<MouseDownEvent>(ect =>
        {
            Debug.Log("pesta�aPaigro");
            NoContenido();
            torPaigro.style.display = DisplayStyle.Flex;
        });

        botAndres.RegisterCallback<MouseDownEvent>(ect =>
        {
            Debug.Log("pesta�aAndres");
            NoContenido();
            torAndres.style.display = DisplayStyle.Flex;
        });

        botNieves.RegisterCallback<MouseDownEvent>(ect =>
        {
            Debug.Log("pesta�a Nieves");
            NoContenido();
            torNieves.style.display = DisplayStyle.Flex;
        });

        Debug.Log("pesta�a Nieves");
        NoContenido();
        torNieves.style.display = DisplayStyle.Flex;

        // Huecos para torres
        huecos[0] = rootve.Q("Torre1");
        huecos[1] = rootve.Q("Torre2");
        huecos[2] = rootve.Q("Torre3");
        huecos[3] = rootve.Q("Torre4");

        magiaEst = rootve.Q("EstrellaM");
        psiquicoEst = rootve.Q("EstrellaP");
        fisicoEst = rootve.Q("EstrellaF");


        // Botones torres
        VisualElement pulpitoT = rootve.Q("PulpitoCont");
        VisualElement mostruitoT = rootve.Q("MonstruitoCont");
        VisualElement tarotistaT = rootve.Q("TarotistaCont");

        VisualElement caitT = rootve.Q("CatiCont");
        VisualElement lilyT = rootve.Q("LilyCont");
        VisualElement oraculoT = rootve.Q("OraculoCont");

        VisualElement reviveT = rootve.Q("ReviveCont");
        VisualElement PaulT = rootve.Q("PaulCont");
        VisualElement RatitaT = rootve.Q("RatitaCont");


        pulpitoT.RegisterCallback<MouseDownEvent, string>(ChangeTorre, "Omen");
        mostruitoT.RegisterCallback<MouseDownEvent, string>(ChangeTorre, "FiddleSticks");
        tarotistaT.RegisterCallback<MouseDownEvent, string>(ChangeTorre, "Tarotista");

        caitT.RegisterCallback<MouseDownEvent, string>(ChangeTorre, "Caitlyn");
        lilyT.RegisterCallback<MouseDownEvent, string>(ChangeTorre, "Flores");
        oraculoT.RegisterCallback<MouseDownEvent, string>(ChangeTorre, "Pedestal");

        reviveT.RegisterCallback<MouseDownEvent, string>(ChangeTorre, "Sage");
        PaulT.RegisterCallback<MouseDownEvent, string>(ChangeTorre, "Paul");
        RatitaT.RegisterCallback<MouseDownEvent, string>(ChangeTorre, "RatiPapa");

        // Boton reset
        VisualElement reset = rootve.Q("Reset");
        reset.RegisterCallback<MouseDownEvent>(clearTorre);

    }

    void ChangeTorre(MouseDownEvent mde, string s)
    {
        huecos[espaciosOcupados].style.backgroundImage = new StyleBackground(Resources.Load<Sprite>(s));
        espaciosOcupados++;

        int rand = Random.Range(0, 3);

        fisicoEst.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>("estrella"));
        psiquicoEst.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>("estrella"));
        magiaEst.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>("estrella"));

        switch (rand)
        {
            case 0:
                magico++;
                magiaEst.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>("estrellaEncendida"));
                Debug.Log("MAGIA");
                break;
            case 1:
                psiquico++;
                psiquicoEst.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>("estrellaEncendida"));
                Debug.Log("PSIQUICO");
                break;
            case 2:
                fisico++;
                fisicoEst.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>("estrellaEncendida"));
                Debug.Log("FIOSICO");
                break;
            default: break;
        }

    }

    void clearTorre(MouseDownEvent mde)
    {
        // vacia huecos
        for (int i = 0; i < espaciosOcupados; i++)
        {
            huecos[i].style.backgroundImage = new StyleBackground(Resources.Load<Sprite>(""));
        }
        espaciosOcupados = 0;

        //resetea stats
        fisico = 0;
        psiquico = 0;
        magico = 0;
    }
}

