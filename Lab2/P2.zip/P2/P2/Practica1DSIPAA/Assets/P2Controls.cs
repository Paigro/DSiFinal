using System.Collections;
using System.Collections.Generic;
using UnityEngine.UIElements;
using UnityEngine;

public class P2Controls : MonoBehaviour
{
    //// Start is called before the first frame update
    //void Start()
    //{

    //}

    //// Update is called once per frame
    //void Update()
    //{

    //}

    private void OnEnable()
    {
        UIDocument controles = GetComponent<UIDocument>();
        VisualElement rootve = controles.rootVisualElement;

        UQueryBuilder<VisualElement> builder = new(rootve);

        VisualElement mslider = rootve.Q<Slider>("saucequantity");
        mslider.style.backgroundColor = Color.magenta;

        VisualElement mdragger = rootve.Q<VisualElement>("unity-dragger");
        mdragger.style.backgroundColor = Color.red;

        VisualElement mtracker = rootve.Q<VisualElement>("unity-tracker");
        mtracker.style.backgroundColor = Color.yellow;
        
        
        VisualElement mslider2 = rootve.Q<Slider>("hotquantity");
        mslider2.style.backgroundColor = Color.red;

        VisualElement mdragger2 = mslider2.Q<VisualElement>("unity-dragger");
        mdragger2.style.backgroundColor = Color.yellow;

        VisualElement mtracker2 = mslider2.Q<VisualElement>("unity-tracker");
        mtracker2.style.backgroundColor = Color.green;


        VisualElement mslider3 = rootve.Q<Slider>("spicesquantity");
        mslider3.style.backgroundColor = Color.green;

        VisualElement mdragger3 = mslider3.Q<VisualElement>("unity-dragger");
        mdragger3.style.backgroundColor = Color.yellow;

        VisualElement mtracker3 = mslider3.Q<VisualElement>("unity-tracker");
        mtracker3.style.backgroundColor = Color.red;
    }

}
