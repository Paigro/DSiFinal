using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class P4 : VisualElement
{
    public new class UxmlFactory : UxmlFactory<P4, UxmlTraits> { };

    public new class UxmlTraits : VisualElement.UxmlTraits
    {
        UxmlIntAttributeDescription mypunt = new UxmlIntAttributeDescription { name = "puntuacion", defaultValue = 0 };

        public override void Init(VisualElement ve, IUxmlAttributes bag, CreationContext cc)
        {
            base.Init(ve, bag, cc);
            var puntuaje = ve as P4;
            puntuaje.Puntuacion = mypunt.GetValueFromBag(bag, cc);
            Debug.Log("Puntuacion: " + puntuaje.Puntuacion);
        }
    }
    VisualElement[] estrellas = new VisualElement[6];

    int puntuacion;

    public int Puntuacion
    {
        get => puntuacion;
        set
        {
            puntuacion = value;
            encenderEstrellas();
        }
    }

    void encenderEstrellas()
    {
        // Apaga estrellas
        for (int i = 0; i < estrellas.Length; i++)
        {
           // estrellas[i].style.backgroundColor = new Color(0.27f, 0, 0);
            estrellas[i].style.backgroundImage = new StyleBackground(Resources.Load<Sprite>("estrellitaapagada"));
        }

        // Enciende estrellas
        for (int i = 0; i < puntuacion; i++)
        {
            //estrellas[i].style.backgroundColor = Color.white;
            estrellas[i].style.backgroundImage = new StyleBackground(Resources.Load<Sprite>("estrellita"));
        }
    }

    public P4()
    {
        VisualTreeAsset template_estrellas = Resources.Load<VisualTreeAsset>("estrella");

        for (int i = 0; i < 6; i++)
        {
            VisualElement estrella = template_estrellas.Instantiate();
            estrella.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>("estrellitaapagada"));

            estrellas[i] = estrella;

            hierarchy.Add(estrella);
        }
    }
}
