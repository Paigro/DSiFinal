using UnityEngine;
using UnityEngine.Assertions.Must;
using UnityEngine.UIElements;

namespace Lab6_namespace
{
    public class Tarjeta
    {
        Individuo miIndividuo;

        VisualElement tarjetaRoot;

        Label nombreLabel;
        Label apellidoLabel;

        public Tarjeta(VisualElement root, Individuo indv)
        {
            this.tarjetaRoot = root;
            this.miIndividuo = indv;

            nombreLabel = root.Q<Label>("Nombre");
            apellidoLabel = root.Q<Label>("Apellido");
            root.userData = miIndividuo;

            UpdateUI();

            miIndividuo.Cambio += UpdateUI;
        }

        void UpdateUI()
        {
            nombreLabel.text = miIndividuo.Nombre;
            apellidoLabel.text = miIndividuo.Apellido;
        }
    }

}